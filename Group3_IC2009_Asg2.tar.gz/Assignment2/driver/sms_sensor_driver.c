#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/random.h>
#include <linux/ktime.h>
#include <linux/delay.h>
#include "sms_sensor.h"

#define DRIVER_NAME "sms_sensor_driver"
#define DEVICE_NAME "sms_sensor"
#define PROC_NAME   "sms_stats"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Group3_IC2009");
MODULE_DESCRIPTION("Assignment 2 - SMS Sensor Kernel Driver");

static int major_num;
static unsigned long read_count = 0;
static int last_temp_scaled = 2500; // 25.00 * 100
static int last_humi_scaled = 5000; // 50.00 * 100
static int sampling_interval_ms = 100;
static ktime_t start_time;
static DEFINE_MUTEX(sensor_mutex);

static ssize_t sms_read(struct file *file, char __user *buf, size_t len, loff_t *offset) {
    char kbuf[128];
    int datalen;
    u32 rand_val;
    long long timestamp_ms;
    int temp_int, temp_dec;
    int humi_int, humi_dec;

    if (*offset > 0)
        return 0;

    mutex_lock(&sensor_mutex);
    
    rand_val = get_random_u32();
    last_temp_scaled = 1500 + (rand_val % 3000); 
    rand_val = get_random_u32();
    last_humi_scaled = 3000 + (rand_val % 6000); 
    
    read_count++;
    timestamp_ms = ktime_to_ms(ktime_get());

    temp_int = last_temp_scaled / 100;
    temp_dec = last_temp_scaled % 100;

    humi_int = last_humi_scaled / 100;
    humi_dec = last_humi_scaled % 100;

    datalen = snprintf(kbuf, sizeof(kbuf), "%lld,%d.%02d,%d.%02d\n", 
                       timestamp_ms, temp_int, temp_dec, humi_int, humi_dec);
    
    mutex_unlock(&sensor_mutex);

    if (len < (size_t)datalen)
        return -EINVAL;

    if (copy_to_user(buf, kbuf, datalen))
        return -EFAULT;

    *offset += datalen;
    
    if (sampling_interval_ms > 0)
        msleep(sampling_interval_ms);

    return datalen;
}

static long sms_ioctl(struct file *file, unsigned int cmd, unsigned long arg) {
    int interval;
    switch (cmd) {
        case SMS_SET_INTERVAL:
            if (copy_from_user(&interval, (int __user *)arg, sizeof(int)))
                return -EFAULT;
            if (interval < 10)
                return -EINVAL;
            mutex_lock(&sensor_mutex);
            sampling_interval_ms = interval;
            mutex_unlock(&sensor_mutex);
            pr_info("%s: Interval set to %d ms\n", DRIVER_NAME, interval);
            break;
        default:
            return -ENOTTY;
    }
    return 0;
}

static int sms_proc_show(struct seq_file *m, void *v) {
    long long uptime_sec = ktime_divns(ktime_sub(ktime_get(), start_time), NSEC_PER_SEC);
    int temp_int, temp_dec, humi_int, humi_dec;
    char line_buf[256];
    
    mutex_lock(&sensor_mutex);
    
    temp_int = last_temp_scaled / 100;
    temp_dec = last_temp_scaled % 100;

    humi_int = last_humi_scaled / 100;
    humi_dec = last_humi_scaled % 100;

    snprintf(line_buf, sizeof(line_buf), 
             "read_count: %lu\nlast_temperature: %d.%02d\nlast_humidity: %d.%02d\ndriver_uptime_seconds: %lld\n",
             read_count, temp_int, temp_dec, humi_int, humi_dec, uptime_sec);
    
    mutex_unlock(&sensor_mutex);
    
    seq_puts(m, line_buf);
    return 0;
}

static int sms_proc_open(struct inode *inode, struct file *file) {
    return single_open(file, sms_proc_show, NULL);
}

static const struct proc_ops sms_proc_ops = {
    .proc_open    = sms_proc_open,
    .proc_read    = seq_read,
    .proc_lseek   = seq_lseek,
    .proc_release = single_release,
};

static const struct file_operations sms_fops = {
    .owner          = THIS_MODULE,
    .read           = sms_read,
    .unlocked_ioctl = sms_ioctl,
};

static int __init sms_init(void) {
    start_time = ktime_get();
    major_num = register_chrdev(0, DEVICE_NAME, &sms_fops);
    if (major_num < 0)
        return major_num;

    proc_create(PROC_NAME, 0, NULL, &sms_proc_ops);
    pr_info("%s loaded with major %d\n", DRIVER_NAME, major_num);
    return 0;
}

static void __exit sms_exit(void) {
    remove_proc_entry(PROC_NAME, NULL);
    unregister_chrdev(major_num, DEVICE_NAME);
    pr_info("%s unloaded\n", DRIVER_NAME);
}

module_init(sms_init);
module_exit(sms_exit);
